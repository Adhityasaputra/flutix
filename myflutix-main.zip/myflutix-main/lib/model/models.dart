import 'dart:io';

import 'package:equatable/equatable.dart';

part 'user.dart';
part 'registration_data.dart';
part 'movie.dart';
part 'promo.dart';
part 'movie_detail.dart';
part 'credit.dart';
part 'theater.dart';
part 'ticket.dart';
part 'flutix_transactions.dart';
