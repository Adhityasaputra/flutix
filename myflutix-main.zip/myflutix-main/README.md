# UTS Mobile 

Informatika B 2021
1. 2109106065 Mahsa Jacinda Putri
2. 2109106088 Fela Afria Ningsih
3. 2109106099 Muhammmad Syarafi Al Fasa
4. 2109106102 Adhitya Saputra
5. 2109106107 Grace Ligit Nuh

