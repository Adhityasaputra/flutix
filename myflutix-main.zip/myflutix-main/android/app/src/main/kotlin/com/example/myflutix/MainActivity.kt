package com.example.myflutix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
