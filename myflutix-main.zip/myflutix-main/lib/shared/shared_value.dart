part of 'shared.dart';

String apiKey = '466caf3e8a67715bca8d4deae4850515';
String? imageBaseURL = 'https://image.tmdb.org/t/p/';

PageEvent? prevPageEvent;
File? imageFileToUpload;
